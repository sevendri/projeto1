package br.com.letscode.turmaitau.produtos.util;

public enum TipoPreco {
    CARO,
    BARATO
}
